/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midterm.midtermexam;

/**
 *
 * @author win
 */
import java.util.Scanner;

public class Question3 {
    public static void main(String[] args) {    
    Scanner sc = new Scanner(System.in);    
    double[] numbers = new double[];
    
        
    for (int i = 0; i <= 10; i++) {
        System.out.print("Number " + i  + ": ");}
    
    double number = sc.nextDouble();
        if (number >= 0; sum = 0){
            sum = number + sum;
    }

        else (number < 0){
            continue;    
        }
        }
        double average = sum / n;
        double minValue = Double.MAX_VALUE;
        double maxValue = Double.MAX_VALUE;
        
                   
        System.out.println("You entered "+ i + " numbers" );
        System.out.println("Min: %.2f ", adjustedMin);
        System.out.println("Max: %.2f ", adjustedMax);
        System.out.println("Sum of numbers: ", sum);
        System.out.println("Average: %.2f%n", average);
}

    
